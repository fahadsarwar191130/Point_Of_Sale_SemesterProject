﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_POS_191190_191130
{
    public partial class Login : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-565CGDJ\SQLEXPRESS;Initial Catalog=POS;Integrated Security=True");

        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Login where UserName=@userName and Password = @password" ,con);

            cmd.Parameters.AddWithValue("userName", textBoxUserName.Text);
            cmd.Parameters.AddWithValue("password", textBoxPassword.Text);
            SqlDataReader reader1;
            reader1 = cmd.ExecuteReader();
            if(reader1.Read())
            {
                con.Close();
                this.Hide();
                Home obj = new Home();
                obj.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password");
                con.Close();
            }
        }
    }
}
