﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_POS_191190_191130
{
    public partial class UCAddProduct : UserControl
    {
        public UCAddProduct()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-565CGDJ\SQLEXPRESS;Initial Catalog=POS;Integrated Security=True");

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            int id = Convert.ToInt32(textBoxId.Text);
            string name = textBoxName.Text;
            string category = comboBoxCategory.Text;
            int price = Convert.ToInt32(textBoxPrice.Text);
            int quantity = Convert.ToInt32(textBoxQuantity.Text);
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert into Products(Id,ProductName,ProductCategory,Price,Quantity)" +
                "values('" + id + "','" + name + "','" + category + "','" + price + "','" + quantity + "')", con);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Data is inserted");
            con.Close();

            textBoxId.Text = "";
            textBoxName.Text = "";
            comboBoxCategory.Text = "";
            textBoxPrice.Text = "";
            textBoxQuantity.Text = "";

        }
    }
}
