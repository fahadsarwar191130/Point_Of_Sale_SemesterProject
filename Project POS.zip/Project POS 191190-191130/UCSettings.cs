﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_POS_191190_191130
{
    public partial class UCSettings : UserControl
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-565CGDJ\SQLEXPRESS;Initial Catalog=POS;Integrated Security=True");
        public UCSettings()
        {
            InitializeComponent();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            string userName = textBoxUserName.Text;
            string password = textBoxPassword.Text;
            if(string.IsNullOrEmpty(userName) & string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Invalid Entry");
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update Login set UserName = '" + userName + "',Password = '" + password + "'", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("UserName and Password Changed");
                con.Close();
            }
            
        }
    }
}
