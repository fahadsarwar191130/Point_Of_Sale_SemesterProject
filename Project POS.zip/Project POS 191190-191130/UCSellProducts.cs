﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_POS_191190_191130
{
    public partial class UCSellProducts : UserControl
    {
        public UCSellProducts()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-565CGDJ\SQLEXPRESS;Initial Catalog=POS;Integrated Security=True");

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBoxSearchName.Text))
            {
                MessageBox.Show("Enter Any Value to Search");
            }
            else
            {
                con.Open();
                SqlDataAdapter dataAdapter = new SqlDataAdapter("Select * from Products where ProductName = '" + txtBoxSearchName.Text + "'", con);

                DataTable dt = new DataTable();
                dataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
        }

        int PPrice, SubTotalPrice = 0, Discount;
        int n = 0, DiscountedPrice;

        
        private void DisplayProducts()
        {
            dateLabel.Text = DateTime.Now.ToLongDateString();
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("Select * from Products", con);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            DisplayProducts();
        }

        private void UCSellProducts_Load(object sender, EventArgs e)
        {
            DisplayProducts();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnAddBill_Click(object sender, EventArgs e)
        {

            PPrice = Convert.ToInt32(dataGridView1.CurrentRow.Cells[3].Value);
            try { PPrice = PPrice * Convert.ToInt32(textBoxQuantity.Text); }
            catch(System.FormatException)
            { MessageBox.Show("Enter Quantity");
                return;
            }
            
            dataGridView2.Rows.Add();
            dataGridView2.Rows[n].Cells[0].Value = dataGridView1.CurrentRow.Cells[0].Value;
            dataGridView2.Rows[n].Cells[1].Value = dataGridView1.CurrentRow.Cells[1].Value;
            dataGridView2.Rows[n].Cells[2].Value = dataGridView1.CurrentRow.Cells[2].Value;
            dataGridView2.Rows[n].Cells[3].Value = dataGridView1.CurrentRow.Cells[3].Value;
            dataGridView2.Rows[n].Cells[4].Value = textBoxQuantity.Text;
            dataGridView2.Rows[n].Cells[5].Value = PPrice.ToString();
            SubTotalPrice = SubTotalPrice + PPrice;
            textBoxSubTotal.Text = "" + SubTotalPrice.ToString();

            n++;
        }

        void ClearData()
        {
            dataGridView2.Rows.Clear();
            textBoxSubTotal.Text = "";
            textBoxTotalAmount.Text = "";
            textBoxDiscount.Text = "";
        }
        private void btnGrandTotal_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxDiscount.Text))
            {
                Discount = Convert.ToInt32(textBoxDiscount.Text);
                DiscountedPrice = SubTotalPrice - (SubTotalPrice * Discount / 100);
                textBoxTotalAmount.Text = DiscountedPrice.ToString();
            }
            else
            {
                textBoxTotalAmount.Text = SubTotalPrice.ToString();
            }
        }
    }
}
