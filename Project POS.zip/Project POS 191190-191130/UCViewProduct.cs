﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_POS_191190_191130
{
    public partial class UCViewProduct : UserControl
    {
        public UCViewProduct()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-565CGDJ\SQLEXPRESS;Initial Catalog=POS;Integrated Security=True");

        private void UCViewProduct_Load(object sender, EventArgs e)
        {
            DisplayProducts();
        }
        private void DisplayProducts()
        {
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("Select * from Products", con);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            DisplayProducts();
        }
    }
}
