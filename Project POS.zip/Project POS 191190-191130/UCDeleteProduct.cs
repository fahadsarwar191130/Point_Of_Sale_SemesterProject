﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_POS_191190_191130
{
    public partial class UCDeleteProduct : UserControl
    {
        public UCDeleteProduct()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-565CGDJ\SQLEXPRESS;Initial Catalog=POS;Integrated Security=True");

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBoxSearchId.Text) && string.IsNullOrEmpty(txtBoxSearchName.Text))
            {
                MessageBox.Show("Enter Any Value to Search");
            }
            else if (!string.IsNullOrEmpty(txtBoxSearchId.Text))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select Id,ProductName,ProductCategory,Price,Quantity from Products where Id=@id", con);
                cmd.Parameters.AddWithValue("id", txtBoxSearchId.Text);
                SqlDataReader reader1;
                reader1 = cmd.ExecuteReader();
                if (reader1.Read())
                {
                    textBoxId.Text = reader1["Id"].ToString();
                    textBoxName.Text = reader1["ProductName"].ToString();
                    comboBoxCategory.Text = reader1["ProductCategory"].ToString();
                    textBoxPrice.Text = reader1["Price"].ToString();
                    textBoxQuantity.Text = reader1["Quantity"].ToString();
                    txtBoxSearchName.Text = reader1["ProductName"].ToString();
                }
                else
                {
                    MessageBox.Show("No Data is found with such ID");
                    txtBoxSearchId.Text = "";
                }
                con.Close();
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select Id,ProductName,ProductCategory,Price,Quantity from Products where ProductName=@name", con);
                cmd.Parameters.AddWithValue("name", txtBoxSearchName.Text);
                SqlDataReader reader1;
                reader1 = cmd.ExecuteReader();
                if (reader1.Read())
                {
                    textBoxId.Text = reader1["Id"].ToString();
                    textBoxName.Text = reader1["ProductName"].ToString();
                    comboBoxCategory.Text = reader1["ProductCategory"].ToString();
                    textBoxPrice.Text = reader1["Price"].ToString();
                    textBoxQuantity.Text = reader1["Quantity"].ToString();
                    txtBoxSearchId.Text = reader1["Id"].ToString();
                }
                else
                {
                    MessageBox.Show("No Data is found with such Name");
                    txtBoxSearchName.Text = "";
                }
                con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBoxSearchId.Text))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from Products Where Id = '" + Convert.ToInt32(txtBoxSearchId.Text) + "'", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data is Deleted");
                con.Close();
            }
            else if (!string.IsNullOrEmpty(txtBoxSearchName.Text))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from Products Where ProductName = '" + txtBoxSearchName.Text + "'", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data is Deleted");
                con.Close();
            }
            else
            {
                MessageBox.Show("Enter some data");
            }

            ClearData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBoxId.Text);
            string name = textBoxName.Text;
            string category = comboBoxCategory.Text;
            int price = Convert.ToInt32(textBoxPrice.Text);
            int quantity = Convert.ToInt32(textBoxQuantity.Text);
            con.Open();
            SqlCommand cmd = new SqlCommand("update Products set Id = '" + id + "',ProductName = '" + name + "',ProductCategory = '" + category + "',Price = '" + price + "',Quantity = " + quantity + " where Id = '" + Convert.ToInt32(txtBoxSearchId.Text) + "'", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data is Updated");
            con.Close();

            ClearData();
        }
        private void ClearData()
        {
            textBoxId.Text = "";
            textBoxName.Text = "";
            comboBoxCategory.Text = "";
            textBoxPrice.Text = "";
            textBoxQuantity.Text = "";
            txtBoxSearchId.Text = "";
            txtBoxSearchName.Text = "";
        }
    }
}
