﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_POS_191190_191130
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            ucDeleteProduct1.Hide();
            ucViewProduct1.Hide();
            ucSellProducts1.Hide();
            ucSettings1.Hide();
            ucAddProduct1.Show();
        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            ucViewProduct1.Hide();
            ucAddProduct1.Hide();
            ucSellProducts1.Hide();
            ucSettings1.Hide();
            ucDeleteProduct1.Show();
        }

        private void btnViewProduct_Click(object sender, EventArgs e)
        {
            ucDeleteProduct1.Hide();
            ucAddProduct1.Hide();
            ucSellProducts1.Hide();
            ucSettings1.Hide();
            ucViewProduct1.Show();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            ucSettings1.Hide();
            ucSellProducts1.Hide();
            ucDeleteProduct1.Hide();
            ucViewProduct1.Hide();
            ucAddProduct1.Hide();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            ucAddProduct1.Hide();
            ucDeleteProduct1.Hide();
            ucViewProduct1.Hide();
            ucSellProducts1.Hide();
            ucSettings1.Hide();
        }

        private void btnSellProduct_Click(object sender, EventArgs e)
        {
            ucAddProduct1.Hide();
            ucDeleteProduct1.Hide();
            ucViewProduct1.Hide();
            ucSettings1.Hide();
            ucSellProducts1.Show();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            ucDeleteProduct1.Hide();
            ucViewProduct1.Hide();
            ucAddProduct1.Hide();
            ucSellProducts1.Hide();
            ucSettings1.Show();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login obj = new Login();
            obj.Show();
        }
    }
}
